package io.dreamteam.practica1_concurrente.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;


@Entity
@Table(name = "Movimientoes")
@Getter
@Setter
public class Movimiento extends Sensor {

    @Column
    private String movimiento;

}
