package io.dreamteam.practica1_concurrente.repos;

import io.dreamteam.practica1_concurrente.domain.Movimiento;
import org.springframework.data.jpa.repository.JpaRepository;


public interface MovimientoRepository extends JpaRepository<Movimiento, Long> {
}
