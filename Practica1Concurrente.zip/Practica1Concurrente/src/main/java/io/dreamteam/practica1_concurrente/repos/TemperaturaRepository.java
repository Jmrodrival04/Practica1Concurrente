package io.dreamteam.practica1_concurrente.repos;

import io.dreamteam.practica1_concurrente.domain.Temperatura;
import org.springframework.data.jpa.repository.JpaRepository;


public interface TemperaturaRepository extends JpaRepository<Temperatura, Long> {
}
